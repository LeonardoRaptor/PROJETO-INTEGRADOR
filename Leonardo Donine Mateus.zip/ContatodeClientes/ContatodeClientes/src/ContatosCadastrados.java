import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class ContatosCadastrados extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Registro sel;
	private RegistrodeContatos y = new RegistrodeContatos();
	private Registro r= new Registro();
	private String a, b;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ContatosCadastrados frame = new ContatosCadastrados();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ContatosCadastrados() {
		setForeground(Color.WHITE);
		setBackground(Color.WHITE);
		setFont(new Font("Times New Roman", Font.PLAIN, 12));
		setTitle("Contatos");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 205);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int posicaoPessoa = table.getSelectedRow();
				
				
				sel = y.registro.get(posicaoPessoa);
				
				a = String.valueOf(r.id3);
				b = String.valueOf(r.telefone3);
				y.textID.setText(a);
				y.textNome.setText(r.getNome3());
				y.textEmail.setText(r.getEmail3());
				y.textEndereo.setText(r.getEndereco3());
				
				y.textTelefone.setText(b);
				if(r.xxx3=="Masculino") {
					y.omboSexo.setSelectedIndex(1);
				}else {
					y.omboSexo.setSelectedIndex(2);
				}
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nome", "Telefone"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnCancelar.setBounds(10, 227, 202, 23);
		contentPane.add(btnCancelar);
		
		JButton btnSelecionar = new JButton("Selecionar");
		btnSelecionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				String nome = y.textNome.getText();
				String telefone = y.textTelefone.getText();
				
				r.setNome3(a);
				r.setTelefone3(r.telefone3);
				
				
			}
		});
		btnSelecionar.setBounds(222, 227, 202, 23);
		contentPane.add(btnSelecionar);
		
	}
}
