
public class Registro {
	public String nome3, endereco3, email3, xxx3;
	public int id3, telefone3;
	public String getNome3() {
		return nome3;
	}
	public void setNome3(String nome3) {
		this.nome3 = nome3;
	}
	public String getEndereco3() {
		return endereco3;
	}
	public void setEndereco3(String endereco3) {
		this.endereco3 = endereco3;
	}
	public String getEmail3() {
		return email3;
	}
	public void setEmail3(String email3) {
		this.email3 = email3;
	}
	public String getXxx3() {
		return xxx3;
	}
	public void setXxx3(String xxx3) {
		this.xxx3 = xxx3;
	}
	public int getId3() {
		return id3;
	}
	public void setId3(int id3) {
		this.id3 = id3;
	}
	public int getTelefone3() {
		return telefone3;
	}
	public void setTelefone3(int telefone3) {
		this.telefone3 = telefone3;
	}
	
	

	
}
