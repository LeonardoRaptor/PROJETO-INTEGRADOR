import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.util.ArrayList;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class RegistrodeContatos extends JFrame {

	private JPanel contentPane;
	public JTextField textID;
	public JTextField textNome;
	public JTextField textEndereo;
	public JTextField textEmail;
	public JTextField textTelefone;
	public JComboBox omboSexo;
	private String  nome, endereco, email, xxx;
	private int id, telefone;
	public ArrayList<Registro> registro = new ArrayList<Registro>();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrodeContatos frame = new RegistrodeContatos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistrodeContatos() {
		
		String [] sexo = {"Masculino", "Feminino"};
		
		Registro x =new Registro();
		
		
		
		
		setFont(new Font("Times New Roman", Font.PLAIN, 12));
		setResizable(false);
		setTitle("Agenda de Contatos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblID = new JLabel("ID");
		lblID.setBounds(10, 11, 54, 14);
		lblID.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblID);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(10, 36, 54, 14);
		lblNome.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblNome);
		
		JLabel lblEndereo = new JLabel("Endere\u00E7o");
		lblEndereo.setBounds(10, 61, 54, 14);
		lblEndereo.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblEndereo);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 86, 54, 14);
		lblEmail.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblEmail);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(10, 111, 54, 14);
		lblTelefone.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblTelefone);
		
		
		
		textID = new JTextField();
		
		textID.setBounds(74, 9, 400, 20);
		textID.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		contentPane.add(textID);
		textID.setColumns(10);
		
		
		textNome = new JTextField();
		textNome.setBounds(74, 34, 400, 20);
		textNome.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		textNome.setColumns(10);
		contentPane.add(textNome);
		
		textEndereo = new JTextField();
		textEndereo.setBounds(74, 59, 400, 20);
		textEndereo.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		textEndereo.setColumns(10);
		contentPane.add(textEndereo);
		
		textEmail = new JTextField();
		textEmail.setBounds(74, 84, 400, 20);
		textEmail.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		textEmail.setColumns(10);
		contentPane.add(textEmail);
		
		textTelefone = new JTextField();
		textTelefone.setBounds(74, 109, 159, 20);
		textTelefone.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		textTelefone.setColumns(10);
		contentPane.add(textTelefone);
		
		
		
		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(243, 112, 46, 14);
		lblSexo.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		contentPane.add(lblSexo);
		
		omboSexo = new JComboBox(sexo);
		omboSexo.setBounds(299, 109, 175, 20);
		omboSexo.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		omboSexo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int sexo1=omboSexo.getSelectedIndex();
				switch(sexo1) {
				case 1:
					xxx="Masculino";
					break;
				case 2:
					xxx="Feminino";
					break;
				}
			}
		});
		contentPane.add(omboSexo);
		
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(10, 136, 64, 23);
		
		btnSalvar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String idS=textID.getText();
				String telefoneS=textTelefone.getText();
			if((idS!=null)&&(nome!=null)&&(endereco!=null)&&(email!=null)&&(telefoneS!=null)) {
				
			
					
				
					
					id = Integer.parseInt(idS);
					
					nome=textNome.getText();
					
					endereco=textEndereo.getText();
					
					email=textEmail.getText();
					
					
					telefone = Integer.parseInt(telefoneS);
					
					
					
					x.setId3(id);
					x.setNome3(nome);
					x.setEndereco3(endereco);
					x.setEmail3(email);
					x.setTelefone3(telefone);
					x.setXxx3(xxx);
					
					registro.add(x);
					
					ContatosCadastrados z = new ContatosCadastrados();
					
					
					
					
					
					Adicionado frame1 = new Adicionado();
					frame1.setVisible(true);
					btnSalvar.setEnabled(false);
			}
			}
		});
		btnSalvar.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnSalvar);
		
		
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(157, 136, 76, 23);
		btnAlterar.setEnabled(false);
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Alterado frame3 = new Alterado();
				frame3.setVisible(true);
				btnAlterar.setEnabled(false);
				
			}
		});
		
		btnAlterar.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(74, 136, 76, 23);
		btnExcluir.setEnabled(false);
		
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				registro.remove(x);
					Removido frame2 = new Removido();
					frame2.setVisible(true);
					btnExcluir.setEnabled(false);
					btnAlterar.setEnabled(false);
					btnSalvar.setEnabled(true);
					
				
				
			}
		});
		
		btnExcluir.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnExcluir);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.setBounds(243, 136, 84, 23);
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ContatosCadastrados cFrame = new ContatosCadastrados();
				cFrame.setVisible(true);
				
				btnExcluir.setEnabled(true);
				btnAlterar.setEnabled(true);
				btnSalvar.setEnabled(false);
				
			}
		});
		btnPesquisar.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnPesquisar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.setBounds(327, 136, 74, 23);
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textID.setText("");
				textNome.setText("");
				textEndereo.setText("");
				textEmail.setText("");
				textTelefone.setText("");
				btnSalvar.setEnabled(true);
				btnExcluir.setEnabled(false);
				btnAlterar.setEnabled(false);
				
			}
		});
		btnLimpar.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnLimpar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.setBounds(400, 136, 74, 23);
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		btnFechar.setFont(new Font("Tahoma", Font.PLAIN, 10));
		contentPane.add(btnFechar);
		
		
	}
}
